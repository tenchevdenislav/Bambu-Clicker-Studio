import streamlit as st
import numpy as np
from PIL import Image, ImageOps
import trimesh
import io, zipfile

st.set_page_config(page_title="Bambu Clicker Studio", page_icon="🖱️", layout="wide")
st.markdown("""
<style>
.stApp {background: linear-gradient(135deg,#101827 0%,#182b35 55%,#10251f 100%); color:#edf5f2}
[data-testid="stSidebar"] {background:#111d29}
h1,h2,h3 {color:#e9fff5}
div.stButton>button, div.stDownloadButton>button {border-radius:12px; font-weight:700}
</style>
""", unsafe_allow_html=True)

st.title("🖱️ Bambu Clicker Studio")
st.caption("Качи изображение • настрой clicker-а • прегледай параметрите • експортирай STL за Bambu Studio")

def box(extents, center):
    m = trimesh.creation.box(extents=extents)
    m.apply_translation(center)
    return m

def cylinder(radius, height, center, sections=64):
    m = trimesh.creation.cylinder(radius=radius, height=height, sections=sections)
    m.apply_translation(center)
    return m

def image_badge(img, width, depth, base_z, relief, resolution=70, invert=False):
    """Raised image relief as a small rectangular badge on the top button."""
    im = ImageOps.grayscale(img).resize((resolution, resolution), Image.Resampling.LANCZOS)
    a = np.asarray(im, dtype=np.float32)/255.0
    if invert: a = 1-a
    h,w = a.shape
    xs = np.linspace(-width/2,width/2,w)
    ys = np.linspace(-depth/2,depth/2,h)
    xx,yy = np.meshgrid(xs,ys)
    top = np.column_stack([xx.ravel(), yy.ravel(), (base_z + a*relief).ravel()])
    bottom = np.column_stack([xx.ravel(), yy.ravel(), np.full(w*h,base_z)])
    verts = np.vstack([top,bottom])
    faces=[]
    for r in range(h-1):
        for c in range(w-1):
            i=r*w+c; j=w*h+i
            faces += [[i,i+1,i+w],[i+1,i+w+1,i+w],
                      [j,j+w,j+1],[j+1,j+w,j+w+1]]
    boundary=list(range(w))+[r*w+w-1 for r in range(1,h)]+[(h-1)*w+c for c in range(w-2,-1,-1)]+[r*w for r in range(h-2,0,-1)]
    off=w*h
    for k,i in enumerate(boundary):
        n=boundary[(k+1)%len(boundary)]
        faces += [[i,n,off+n],[i,off+n,off+i]]
    return trimesh.Trimesh(vertices=verts, faces=np.asarray(faces), process=True)

def make_housing(L,W,H,wall,floor,hole_d,rounding,stem_h,stem_loose,body_h):
    # Hollow lower shell, open at the top. Floor is split around a true switch opening.
    parts=[
        box((L,W,floor),(L/2,W/2,floor/2)),
        box((L,wall,H),(L/2,wall/2,H/2)),
        box((L,wall,H),(L/2,W-wall/2,H/2)),
        box((wall,W-2*wall,H),(wall/2,W/2,H/2)),
        box((wall,W-2*wall,H),(L-wall/2,W/2,H/2)),
    ]
    # Switch mounting collar: the center bore is represented by a hollow ring.
    outer=max(hole_d/2+2.0, hole_d/2+stem_loose+1.0)
    ring=trimesh.creation.annulus(r_min=hole_d/2, r_max=outer, height=2.0, sections=64)
    ring.apply_translation((L/2,W/2,floor+1.0))
    parts.append(ring)
    # Internal switch guide rails / stops
    guide_h=min(body_h, H-floor)
    parts.append(box((wall, W*0.55, max(1.0,guide_h)),(L*0.25,W/2,floor+guide_h/2)))
    parts.append(box((wall, W*0.55, max(1.0,guide_h)),(L*0.75,W/2,floor+guide_h/2)))
    return trimesh.util.concatenate(parts)

def make_button(L,W,top_h,wall,stem_h,stem_loose,button_w,button_d,relief, image=None,rounding=1.0):
    # Button top is a rounded-rectangle-like plate (simple printable rectangular geometry).
    plate_t=max(1.8,top_h*0.28)
    plate=box((button_w,button_d,plate_t),(L/2,W/2,top_h-plate_t/2))
    # Four underside guide tabs help keep the cap aligned inside the housing.
    tab_gap=max(0.15,stem_loose)
    tab_w=max(1.0,wall*0.65)
    tabs=[
        box((tab_w,button_d*0.72,top_h),(L/2-button_w/2+tab_w/2+tab_gap,W/2,top_h/2)),
        box((tab_w,button_d*0.72,top_h),(L/2+button_w/2-tab_w/2-tab_gap,W/2,top_h/2)),
    ]
    # Stem below the cap; sized from the switch/stem settings.
    stem=cylinder(radius=max(2.0, min(button_w,button_d)*0.18),height=stem_h,
                  center=(L/2,W/2,top_h-stem_h/2-plate_t))
    pieces=[plate,stem]+tabs
    if image is not None:
        badge_w=min(button_w*0.78, max(8.0,button_w-2*rounding))
        badge_d=min(button_d*0.78, max(8.0,button_d-2*rounding))
        pieces.append(image_badge(image,badge_w,badge_d,top_h+0.001,relief))
    return trimesh.util.concatenate(pieces)

def export_stl(mesh):
    return mesh.export(file_type="stl")

with st.sidebar:
    st.header("⚙️ Настройки на модела")
    st.subheader("SHAPE")
    longest = st.slider("Longest side (mm)", 35, 100, 65)
    width = st.slider("Ширина (mm)", 25, 65, 38)
    top_height = st.slider("Top height (mm)", 5.0, 18.0, 8.0, 0.5)
    wall = st.slider("Wall (mm)", 1.2, 4.0, 1.8, 0.1)
    side_gap = st.slider("Side gap (mm)", 0.10, 0.80, 0.40, 0.05)
    rounding = st.slider("Round the edges (mm)", 0.0, 4.0, 1.2, 0.1)
    st.selectbox("How the top sits", ["Free", "Flush", "Recessed"], index=0)
    st.selectbox("Attachment", ["Без халка", "Keychain loop"], index=1)
    st.subheader("SWITCH")
    switch_hole = st.slider("Switch hole (mm)", 8.0, 20.0, 14.0, 0.5)
    stem_loose = st.slider("Stem looseness (mm)", 0.0, 0.8, 0.2, 0.05)
    white_part = st.slider("White part inside (mm)", 1.0, 8.0, 4.0, 0.5)
    switch_body_h = st.slider("Switch body height (mm)", 5.0, 20.0, 11.0, 0.5)
    stem_h = st.slider("Stem height (mm)", 1.0, 10.0, 4.0, 0.5)
    left_right = st.slider("Left / right (mm)", -10.0, 10.0, 0.0, 0.5)
    up_down = st.slider("Up / down (mm)", -10.0, 10.0, 0.0, 0.5)
    st.subheader("PICTURE")
    relief_h = st.slider("Релеф на изображението (mm)", 0.0, 3.0, 0.8, 0.1)
    invert = st.checkbox("Обърни релефа")

uploaded = st.file_uploader("📷 Качи PNG / JPG / WEBP изображение за тематичния дизайн", type=["png","jpg","jpeg","webp"])
image=None
if uploaded:
    image=Image.open(uploaded).convert("RGB")
    st.image(image, caption="Твоето изображение", width=220)

st.markdown("### 🧩 Генериране")
st.write("Моделът се експортира като две печатаеми части: **долен корпус** и **горен бутон с тематичен релеф**. Switch-ът е отделен купен компонент, който се поставя в отвора.")
if st.button("✨ Генерирай clicker", type="primary", use_container_width=True):
    if longest <= 2*wall+switch_hole:
        st.error("Увеличи дължината или намали дебелината на стените/отвора.")
    elif width <= 2*wall+switch_hole:
        st.error("Увеличи ширината или намали отвора за switch.")
    else:
        with st.spinner("Създавам двете части..."):
            # Offset image placement by the requested controls.
            L=float(longest); W=float(width)
            housing=make_housing(L,W,top_height+switch_body_h+white_part,wall,2.0,switch_hole,rounding,stem_h,stem_loose,switch_body_h)
            button=make_button(L,W,top_height,wall,stem_h,stem_loose,
                               min(L-2*wall,L*0.72),min(W-2*wall,W*0.72),
                               relief_h,image,rounding)
            # Translate the button's image/design alignment as requested.
            button.apply_translation((left_right,up_down,0))
            st.success("Готово — генерирани са две STL части.")
            c1,c2=st.columns(2)
            with c1:
                st.download_button("⬇️ 1. Долен корпус STL",export_stl(housing),"clicker_lower_housing.stl","model/stl")
            with c2:
                st.download_button("⬇️ 2. Горен бутон STL",export_stl(button),"clicker_top_button.stl","model/stl")
            bundle=io.BytesIO()
            with zipfile.ZipFile(bundle,"w",zipfile.ZIP_DEFLATED) as z:
                z.writestr("clicker_lower_housing.stl",export_stl(housing))
                z.writestr("clicker_top_button.stl",export_stl(button))
                z.writestr("PRINT_NOTES.txt",
                    "Bambu Clicker Studio prototype. Import both STL files into Bambu Studio. "
                    "The switch is a separate purchased component. Verify switch dimensions, "
                    "clearances, orientation and fit before printing. A test print is recommended.")
            st.download_button("📦 Изтегли двете части в ZIP",bundle.getvalue(),"clicker_two_parts.zip","application/zip")
            st.info("Преди печат провери размера на реалния switch. Направи малък тест за хлабините — стойностите зависят от конкретния switch и материала.")
st.divider()
st.caption("Bambu Clicker Studio • STL в mm • Подходящо за отваряне в Bambu Studio. Цветовете от снимката се използват като релеф, не като цветен STL.")
